function addTask () {
  var input = document.getElementById("input");
  
  var newTask = input.value;
  
  if (newTask != "") {
   
    var item = document.createElement("li");
    
    
    item.innerHTML = '<input type="button" class="done" onclick="markDone(this.parentNode)" value="&#x2713;" /> ' + 
    '<input type="button" class="remove" onclick="remove(this.parentNode)" value="&#x2715;" /> ' +
    newTask;
  
    document.getElementById("tasks").appendChild(item);  
    
     
    input.value=  '    '
    input.placeholder= 'Enter New Task'
  }
}




function markDone (item) { 
    item.className = 'finished';
}


function remove (item) {
  
  if (item.className =='finshed'){
       item.remove();
  }
}


  function doAbout() {
 var v1 = document.getElementById("divabout");
  v1.innerHTML = "Author is Aaron Trebitz";
  v1.className = "aboutcolor";
  
  
}


function clearAbout() {
    let author = document.getElementById("about");
  author.innerText = "";
}